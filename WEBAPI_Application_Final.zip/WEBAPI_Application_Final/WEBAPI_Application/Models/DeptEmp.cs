﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WEBAPI_Application.Models
{
    public class DeptEmp
    {
        public Department dept { get; set; }
        public Employee emp { get; set; }
    }
}