﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace WEBAPI_Application.Models
{
    [MetadataType(typeof(DepartmentMetadata))]
    public partial class Department
    {
        private class DepartmentMetadata
        {
            [Required(ErrorMessage ="DeptNo is Must")]
            [NumericValiation(ErrorMessage ="Value Cannot be Negative")]
            public int DeptNo { get; set; }
            [Required(ErrorMessage = "DeptName is Must")]
            public string DeptName { get; set; }
            [Required(ErrorMessage = "Location is Must")]
            public string Location { get; set; }
            [Required(ErrorMessage = "Capacity is Must")]
            public int Capacity { get; set; }
        }
    }


    public class NumericValiationAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            int val = (int)value;

            if (val < 0)
            {
                return false;
            }
            return true;
        }
    }

   

    [MetadataType(typeof(EmployeeMetadata))]
    public partial class Employee : IValidatableObject
    {
        private class EmployeeMetadata
        {
            public int EmpNo { get; set; }
            [Required(ErrorMessage ="EmpName is Must")]
            public string EmpName { get; set; }
        } 

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Salary <= 0 || Salary > 100000)
            {
                yield return new ValidationResult("Please enter Salary in Range less than 1L");
            }
            if (String.IsNullOrEmpty(EmpName))
            {
                yield return new ValidationResult("Employee Name must be entered");
            }
        }
    }
}