﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.Results;
using WEBAPI_Application.Models;

using WEBAPI_Application.Repository;
namespace WEBAPI_Application.Controllers
{
    public class EmployeeAPIController : ApiController
    {
        EmployeeRepository _empRepo;

        public EmployeeAPIController()
        {
            _empRepo = new Repository.EmployeeRepository(); 
        }
        
        [ResponseType(typeof(IEnumerable<Employee>))]
        public IHttpActionResult Get()
        {
            var emps = _empRepo.Get();
            return Ok(emps);
        }

        [ResponseType(typeof(Employee))]
        public IHttpActionResult Get(int id)
        {
            var emp = _empRepo.Get(id);
            return Ok(emp);
        }

        [ResponseType(typeof(Employee))]
        public IHttpActionResult Post(Employee emp)
        {
            if (ModelState.IsValid)
            {
                emp = _empRepo.Create(emp);
                return Ok(emp);
            }
            else {
                return new ResponseMessageResult(
                    Request.CreateErrorResponse(HttpStatusCode.NotAcceptable,
                    new HttpError(ModelState, true))
                    );
            }
        }
    }
}
