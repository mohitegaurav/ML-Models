﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.Results;
using WEBAPI_Application.Models;
using WEBAPI_Application.Repository;
using System.Web.Http.Cors;

using WEBAPI_Application.CustomFilters;

namespace WEBAPI_Application.Controllers
{
    //[LogActionFilter]
    [EnableCors("*","*","*")]
    public class DepartmentAPIController : ApiController
    {
        //DepartmentRepository _deptRepo;
        IRepository<Department,int> _deptRepo;
        public DepartmentAPIController(IRepository<Department, int> d)
        {
            _deptRepo = d;
        }

        [ResponseType(typeof(IEnumerable<Department>))]
        public IHttpActionResult Get()
        {
            return  Ok(_deptRepo.Get());
        }

        [ResponseType(typeof(Department))]
        public IHttpActionResult Get(int id)
        {
            return Ok(_deptRepo.Get(id));
        }

        [ResponseType(typeof(Department))]
        public IHttpActionResult Post(Department dept)
        {
            if (ModelState.IsValid)
            {
                var d = _deptRepo.Create(dept);
                return Ok(d);
            }
            else {
                //return BadRequest(ModelState); 
                return new ResponseMessageResult(
                    Request.CreateErrorResponse(HttpStatusCode.NotAcceptable,
                    new HttpError(ModelState, true))
                 );
            }
            
        }
        [ResponseType(typeof(bool))]
        public IHttpActionResult Put(int id, Department dept)
        {
            if (ModelState.IsValid)
            {
                return Ok( _deptRepo.Update(id, dept));
            }
            else
            {
                //return BadRequest("Error in Posted Data " + ModelState);
                return new ResponseMessageResult(
                     Request.CreateErrorResponse(HttpStatusCode.Forbidden,
                     new HttpError(ModelState, true))
                  );
            }
            
        }
        [ResponseType(typeof(bool))]
        public IHttpActionResult Delete(int id)
        {
            return Ok(_deptRepo.Delete(id));
        }

    }
}
