﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;
using WEBAPI_Application.Models;
namespace WEBAPI_Application.Controllers
{
    public class DeptEmpAPIController : ApiController
    {
        ApplicationEntities ctx;

        public DeptEmpAPIController()
        {
            ctx = new Models.ApplicationEntities(); 
        }

        //public IHttpActionResult Post([FromUri]Department dept, [FromBody]Employee emp)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        ctx.Departments.Add(dept);
        //        ctx.Employees.Add(emp);
        //        int res = ctx.SaveChanges();
        //        return Ok(res);
        //    }
        //    else {
        //        return new ResponseMessageResult(Request.CreateErrorResponse(
        //               HttpStatusCode.BadRequest,
        //               new HttpError(ModelState,true)
        //            ));
        //    }
        //}

        public IHttpActionResult Post(DeptEmp d)
        {
            if (ModelState.IsValid)
            {
                ctx.Departments.Add(d.dept);
                ctx.Employees.Add(d.emp);
                int res = ctx.SaveChanges();
                return Ok(res);
            }
            else
            {
                return new ResponseMessageResult(Request.CreateErrorResponse(
                       HttpStatusCode.BadRequest,
                       new HttpError(ModelState, true)
                    ));
            }
        }
    }
}
