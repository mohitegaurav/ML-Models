﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WEBAPI_Application.Models;

namespace WEBAPI_Application.Controllers
{
    [RoutePrefix("cpapi")]
    public class ProdCatAPIController : ApiController
    {
        [Route("get/{cname}/{filter}/{pname}")]
        [ResponseType(typeof(Product))]
        public IHttpActionResult Get(string cname,string filter, string pname)
        {
            List<Product> products = new List<Models.Product>();
            var catId = (from c in new Categories()
                         where c.CategoryName == cname
                         select c).FirstOrDefault().CategoryId;

            switch (filter)
            {
                case "OR":
                     products = (from p in new Products()
                                    where p.CategoryId == catId || p.ProductName==pname
                                    select p).ToList();
                    break;
                case "AND":
                    products = (from p in new Products()
                                where p.CategoryId == catId && p.ProductName == pname
                                select p).ToList();
                    break;

            }

           
            return Ok(products);
        }
    }
}
