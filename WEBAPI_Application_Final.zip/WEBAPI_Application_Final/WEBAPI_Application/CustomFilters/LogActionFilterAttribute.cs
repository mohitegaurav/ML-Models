﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Diagnostics;

namespace WEBAPI_Application.CustomFilters
{
    public class LogActionFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            string logData = "In Action Executing State";
            logData += actionContext.ControllerContext.ControllerDescriptor.ControllerName;
            logData+= actionContext.ActionDescriptor.ActionName;

            Debug.WriteLine(logData);
        }
        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            string logData = "In Action Executed State";
            Debug.WriteLine(logData);
        }
    }
}