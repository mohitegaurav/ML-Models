using Microsoft.Practices.Unity;
using System.Web.Http;
using Unity.WebApi;
using WEBAPI_Application.Models;
using WEBAPI_Application.Repository;

namespace WEBAPI_Application
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            
            container.RegisterType<IRepository<Department,int>, DepartmentRepository>();
            container.RegisterType<IRepository<Employee, int>, EmployeeRepository>();

            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}