﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WEBAPI_Application.Models;

namespace WEBAPI_Application.Repository
{
    public interface IRepository<TEntity, TPk> where TEntity : class
    {
        IEnumerable<TEntity> Get();
        TEntity Get(TPk id);
        TEntity Create(TEntity entity);
        bool Update(TPk id, TEntity entity);
        bool Delete(TPk id);
    }

    public class DepartmentRepository : IRepository<Department, int>
    {
        [Dependency]
        public ApplicationEntities ctx { get; set; }

        //ApplicationEntities ctx;
        //public DepartmentRepository()
        //{
        //    ctx = new ApplicationEntities(); 
        //}
        public Department Create(Department entity)
        {
            ctx.Departments.Add(entity);
            ctx.SaveChanges();
            return entity;
        }

        public bool Delete(int id)
        {
            var dept = ctx.Departments.Find(id);
            if (dept != null)
            {
                ctx.Departments.Remove(dept);
                ctx.SaveChanges();
                return true;
            }
            return false;
        }

        public IEnumerable<Department> Get()
        {
            var depts = ctx.Departments.ToList();
            return depts;
        }

        public Department Get(int id)
        {
            var dept = ctx.Departments.Find(id);
            return dept;
        }

        public bool Update(int id, Department entity)
        {
            var dept = ctx.Departments.Find(id);
            if (dept != null)
            {
                dept.DeptName = entity.DeptName;
                dept.Location = entity.Location;
                dept.Capacity = entity.Capacity;
                ctx.SaveChanges();
                return true;
            }
            return false;
        }
    }

    public class EmployeeRepository : IRepository<Employee, int>
    {
        ApplicationEntities ctx;

        public EmployeeRepository()
        {
            ctx = new Models.ApplicationEntities();
        }
        public Employee Create(Employee entity)
        {
            ctx.Employees.Add(entity);
            ctx.SaveChanges();
            return entity;
        }

        public bool Delete(int id)
        {
            var emp = ctx.Employees.Find(id);
            if (emp != null)
            {
                ctx.Employees.Remove(emp);
                ctx.SaveChanges();
                return true;
            }
            return false;
        }

        public IEnumerable<Employee> Get()
        {
            var emps = ctx.Employees.ToList();
            return emps;
        }

        public Employee Get(int id)
        {
            var emp = ctx.Employees.Find(id);
            return emp;
        }

        public bool Update(int id, Employee entity)
        {
            var emp = ctx.Employees.Find(id);
            if (emp != null)
            {
                emp.EmpName = entity.EmpName;
                emp.Salary = entity.Salary;
                emp.Designation = entity.Designation;
                emp.DeptUniqueId = entity.DeptUniqueId;
                ctx.SaveChanges();
                return true;
            }
            return false;
        }
    }

}