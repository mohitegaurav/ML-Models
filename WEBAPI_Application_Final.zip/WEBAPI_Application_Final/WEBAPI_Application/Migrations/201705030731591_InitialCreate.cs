namespace WEBAPI_Application.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Departments",
                c => new
                    {
                        DeptUniqueId = c.Int(nullable: false, identity: true),
                        DeptNo = c.Int(nullable: false),
                        DeptName = c.String(),
                        Location = c.String(),
                        Capacity = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.DeptUniqueId);
            
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        EmpUniqueId = c.Int(nullable: false, identity: true),
                        EmpNo = c.Int(nullable: false),
                        EmpName = c.String(),
                        Salary = c.Int(nullable: false),
                        Designation = c.String(),
                        DeptUniqueId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.EmpUniqueId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Employees");
            DropTable("dbo.Departments");
        }
    }
}
