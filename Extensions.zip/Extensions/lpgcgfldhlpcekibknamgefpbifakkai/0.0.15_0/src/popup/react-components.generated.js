class DropdownItem extends React.Component {

    handleClick() {
        this.props.onSelect(this.props.value);
    }

    render() {
        return React.createElement(
            "li",
            null,
            React.createElement(
                "a",
                { onClick: this.handleClick.bind(this) },
                this.props.value
            )
        );
    }
}

class Dropdown extends React.Component {

    constructor(props) {
        super(props);
        this.state = { selected: props.selectedItem || props.items[0] };
        this.selectItem = this.selectItem.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        // any updates from parent
        if (nextProps === this.props) {
            // no change
            return;
        }
        //console.log('component will receive props');
        var selectedItem = nextProps.selectedItem || nextProps.items[0];
        this.setState({ selected: selectedItem });
    }

    selectItem(value) {
        this.setState({ selected: value });
        if (this.props.onSelect) {
            this.props.onSelect(value);
        }
    }

    getValue() {
        // called by ref
        return this.state.selected;
    }

    render() {
        var THIS = this;
        return React.createElement(
            "div",
            { className: THIS.props.className },
            React.createElement(
                "button",
                { type: "button", className: "btn btn-default dropdown-toggle",
                    "data-toggle": "dropdown", "aria-haspopup": "true", "aria-expanded": "false" },
                THIS.state.selected,
                " ",
                React.createElement("span", { className: "caret" })
            ),
            React.createElement(
                "ul",
                { className: "dropdown-menu" },
                THIS.props.items.map(function (method) {
                    return React.createElement(DropdownItem, { onSelect: THIS.selectItem, value: method });
                })
            )
        );
    }
}
function HeaderInput(props) {
    return React.createElement(
        "div",
        { className: "row" },
        React.createElement(
            "div",
            { className: "col-xs-5" },
            React.createElement("input", { type: "text", className: "form-control", placeholder: "key", value: props.item.key,
                onFocus: props.addItem, onChange: props.updateKey })
        ),
        React.createElement(
            "div",
            { className: "col-xs-5" },
            React.createElement("input", { type: "text", className: "form-control", placeholder: "value", value: props.item.value,
                onFocus: props.addItem, onChange: props.updateValue })
        ),
        React.createElement(
            "div",
            null,
            React.createElement(
                "a",
                null,
                React.createElement("span", { className: "glyphicon glyphicon-remove", "aria-hidden": "true",
                    onClick: props.removeItem })
            )
        )
    );
}

class HeaderInputList extends React.Component {

    constructor(props) {
        super(props);
        this.state = { headers: [] };
        this.addInput(-1);
    }

    componentWillReceiveProps(nextProps) {
        // any updates from parent
        if (nextProps === this.props) {
            // no change
            return;
        }
        var THIS = this;
        THIS.state.headers = [];
        THIS.addInput(-1);
        nextProps.headerList && nextProps.headerList.forEach(function (header, i) {
            var arr = header.split(':');
            THIS.updateHeader(i, 'key', arr[0]);
            THIS.updateHeader(i, 'value', arr[1]);
            THIS.addInput(i);
        });
    }

    addInput(ind) {
        var items = this.state.headers;
        if (items.length - ind === 1) {
            items.push({ key: "", value: "" });
            this.setState({ headers: items });
        }
    }

    removeInput(ind) {
        if (this.state.headers.length !== 1) {
            this.state.headers.splice(ind, 1);
            this.setState({ headers: this.state.headers });
        }
    }

    updateHeader(i, k, e) {
        if (typeof e === 'string') {
            // text
            this.state.headers[i][k] = e;
        } else {
            // event
            this.state.headers[i][k] = e.target.value;
        }
        this.setState({ headers: this.state.headers });
    }

    getValue() {
        return this.state.headers.map(h => h.key ? h.key + ":" + h.value : "").filter(item => item !== "");
    }

    render() {
        var THIS = this;
        return React.createElement(
            "div",
            { className: "headers-input", onClick: this.props.onClick.bind(this) },
            THIS.state.headers.map(function (item, ind) {
                return React.createElement(HeaderInput, { item: item, addItem: THIS.addInput.bind(THIS, ind),
                    removeItem: THIS.removeInput.bind(THIS, ind),
                    updateKey: THIS.updateHeader.bind(THIS, ind, 'key'),
                    updateValue: THIS.updateHeader.bind(THIS, ind, 'value') });
            })
        );
    }
}
class DroppableArea extends React.Component {

    constructor(props) {
        super(props);
        this.eventHandlers = {};
    }

    componentWillReceiveProps(nextProps) {
        // any updates from parent
        this.isOpen = !!nextProps.isOpening;
    }

    componentDidMount() {
        // Setup the dnd listeners.
        var droppableElement = $(this.self);
        var triggerHandler = function (handlerCallback) {
            var THIS = this;
            return function (evt) {
                evt.preventDefault();
                evt.dataTransfer.dropEffect = window.dropEffect;
                if (THIS.isOpen) {
                    handlerCallback(evt);
                }
            };
        }.bind(this);

        this.eventHandlers.dragenter = triggerHandler(function handleDragEnter(evt) {
            //console.log('handleDragEnter', evt);
            if (droppableElement.is(evt.target) || droppableElement.find(evt.target)[0]) {
                window.dropEffect = 'copy';
            } else {
                window.dropEffect = 'none';
            }
            evt.dataTransfer.dropEffect = window.dropEffect;
            droppableElement.find('.dragover').removeClass('hide-me-imp');
        });

        this.eventHandlers.dragover = triggerHandler(_.debounce(function handleDragOver(evt) {
            //console.log('handleDragOver', evt.target);
            droppableElement.find('.dragover').addClass('hide-me-imp');
        }, 200));

        this.eventHandlers.drop = triggerHandler(function handleFileSelect(evt) {
            // dropped on itself or one of its children
            if (droppableElement.is(evt.target) || droppableElement.find(evt.target)[0]) {
                //console.log('handleFileSelect', evt.target, evt);
                var files = evt.dataTransfer.files; // FileList object.
                var reader = new FileReader();
                droppableElement.find('.dragover:not(.hide-me-imp)').addClass('hide-me-imp');
                reader.onload = function (event) {
                    droppableElement[0].children[0].value = event.target.result;
                };
                reader.readAsText(files[0], "UTF-8");
            }
        });

        document.addEventListener('dragenter', this.eventHandlers.dragenter, false);
        document.addEventListener('dragover', this.eventHandlers.dragover, false);
        document.addEventListener('drop', this.eventHandlers.drop, false);
    }

    componentWillUnmount() {
        document.removeEventListener('dragenter', this.eventHandlers.dragenter);
        document.removeEventListener('dragover', this.eventHandlers.dragover);
        document.removeEventListener('drop', this.eventHandlers.drop);
    }

    render() {
        return React.createElement(
            'div',
            { className: 'droppable-area', ref: self => {
                    this.self = self;
                } },
            this.props.children,
            React.createElement(
                'div',
                { className: 'dragover hide-me-imp' },
                React.createElement(
                    'div',
                    { className: 'border-dragover' },
                    React.createElement(
                        'span',
                        { className: 'content' },
                        'DROP File'
                    )
                )
            )
        );
    }
}

class HttpFormPanel extends React.Component {

    constructor(props) {
        super(props);
        this.elm = {};
        this.HTTP_METHODS = ["GET", "POST", "PUT", "DELETE", "JSONP", "PATCH", "HEAD"];
        this.HTTP_RESPONSE_TYPES = ["Response text", "Response through file"];
        this.state = this.getDefaultStateValues(props);
        this.state.isOpening = false;
        this.handleSubmit = this.handleSubmit.bind(this);
        this.resetForm = this.resetForm.bind(this);
        // init or reset the form
        var THIS = this;
        this.resetForm(() => {
            if (THIS.props.updateInitErrorState) {
                var httpErrorState = THIS.getErrorState();
                birbalJS.logger.log(THIS.props);
                THIS.props.updateInitErrorState(httpErrorState);
            }
        });
    }

    componentDidMount() {
        function findMatches(q, cb) {
            // an array that will be populated with substring matches
            var matches = [],
                str = "new RegExp";

            // regex used to determine if a string contains the substring `q`
            // contains the substring `q`, add it to the `matches` array
            if (new RegExp(q, 'i').test(str)) {
                matches.push(str.concat('("", "")'));
            }
            cb(matches);
        }

        // registered typeahead
        $(this.elm.url).typeahead(null, { source: findMatches });
        birbalJS.logger.info('componentDidMount for ' + this.props.name);
        var THIS = this;
        $("#collapse-" + this.props.name).on("openingForm", function () {
            THIS.showHelpPanel("method");
        });
        $("#collapse-" + this.props.name).on("show.bs.collapse  hide.bs.collapse", function (evt) {
            THIS.setState({ isOpening: evt.type === 'show' });
        });
    }

    getRegExpArgs(value) {
        // 2. verify regexp signature
        // 3. retrieve flags
        // 4. retrieve pattern
        function retrievePattern(str) {
            // single quote
            // double quote
            var regmatched = str.match(/(['"\/])(.+)\1(?:\s*,\s*['"]\w*['"])$/);
            if (regmatched) {
                return regmatched[2];
            }
            regmatched = str.match(/(['"\/])(.+)\1(?:\s*,\s*['"]\w*['"])?$/);
            return regmatched && regmatched[2];
        }

        //#1 & #2
        value = value.match(/^new RegExp\((.*)\)$/);
        if (!value) {
            return;
        }
        value = value[1];
        //#4
        var pattern = retrievePattern(value);
        //#3
        var flags = value.replace(pattern, '').replace(/['\"\/,]/g, '').trim();
        birbalJS.logger.log.bind(null, 'regex  ').call(null, { pattern: pattern, flags: flags });
        return { pattern: pattern, flags: flags };
    }

    validateURLRegexp(errorState) {
        // 1. get value
        // 2. verify and validate regExp expression
        // 5. validate regexp
        try {
            //#1
            var regexObject = this.getRegExpArgs(this.elm.url.value);
            //#5
            if (regexObject) {
                new RegExp(regexObject.pattern, regexObject.flags);
            }
        } catch (e) {
            // not valid
            errorState.url = errorState.url.concat(',regexInvalid');
        }
    }

    getErrorState() {
        var errorState = {},
            elm;
        // required state
        for (var name in this.elm) {
            elm = this.elm[name];
            if (!elm) {
                continue;
            }
            // initialize
            errorState[name] = "";
            if (elm.dataset && elm.dataset.httpRequired === 'true' && !(elm.value || elm.getValue && elm.getValue())) {
                errorState[name] = errorState[name].concat(',httpRequired');
            }
        }
        this.validateURLRegexp(errorState);
        return errorState;
    }

    handleSubmit(e) {
        e.preventDefault();
        var httpMock = {
            status: this.elm.status.value,
            headers: this.elm.headers.getValue(),
            method: this.elm.httpMethod.getValue()
        };
        if (this.state.httpResponseType === this.HTTP_RESPONSE_TYPES[0]) {
            httpMock.response = this.elm.responseData.value;
        } else {
            httpMock.fileResponse = this.elm.fileResponse.value;
            if (httpMock.fileResponse) {
                if (httpMock.fileResponse.indexOf('http') !== 0) {
                    httpMock.fileResponse = 'http://' + httpMock.fileResponse;
                }
            }
        }

        try {
            httpMock.url = birbalJS.toURL(this.getRegExpArgs(this.elm.url.value));
        } finally {
            httpMock.url = httpMock.url || this.elm.url.value;
        }
        var httpErrorState = this.getErrorState();
        this.hideHelpPanel();
        this.props.save(httpMock, httpErrorState);
        // reset the form
        //this.resetForm();
    }

    validateForm() {
        var httpErrorState = this.getErrorState(),
            classList;
        for (var name in httpErrorState) {
            classList = ReactDOM.findDOMNode(this.elm[name]).parentElement.classList;
            if (httpErrorState[name].length !== 0) {
                classList.add('has-error');
            } else {
                classList.remove('has-error');
            }
        }
    }

    // generate from properties
    getDefaultStateValues(props) {
        if (!props) {
            props = this.props;
        }
        var stateValues = {
            httpMethod: props.method || this.HTTP_METHODS[0],
            headerList: props.headerList || []
        };
        if (props.responseData === undefined && props.fileResponse) {
            stateValues.httpResponseType = this.HTTP_RESPONSE_TYPES[1];
        } else {
            stateValues.httpResponseType = this.HTTP_RESPONSE_TYPES[0];
        }
        return stateValues;
    }

    resetForm(callback) {
        var THIS = this;
        this.hideHelpPanel();
        var defaultState = this.getDefaultStateValues();
        this.setState(defaultState);
        window.setTimeout(function () {
            if (THIS.state.httpResponseType === THIS.HTTP_RESPONSE_TYPES[1]) {
                // its file reference
                THIS.elm.fileResponse.value = THIS.props.fileResponse;
            } else {
                // default response data
                THIS.elm.responseData.value = THIS.props.responseData || "";
            }
            THIS.elm.url.value = THIS.props.url && THIS.props.url.toString() || "";
            THIS.elm.status.value = THIS.props.status || "200";
            if (typeof callback === 'function') {
                callback();
            }
            if (!THIS.props.noValidate) {
                THIS.validateForm();
            }
        }, 200);
    }

    showHelpPanel(panelName) {
        var panelList = panelName ? [panelName] : panelName;
        $(".http-input-help").trigger("help-panel:hide");
        $(".http-input-help").trigger("help-panel:show", panelList);
        if (panelName === 'response') {
            $('.nav.nav-pills li .btn.dropdown-toggle').addClass('btn-primary');
        } else {
            $('.nav.nav-pills li .btn.dropdown-toggle').removeClass('btn-primary');
        }
    }

    hideHelpPanel(panelName) {
        var panelList = panelName ? [panelName] : panelName;
        $(".http-input-help").trigger("help-panel:hide", panelList);
        if (panelName === 'response') {
            $('.nav.nav-pills li .btn.dropdown-toggle').addClass('btn-primary');
        } else {
            $('.nav.nav-pills li .btn.dropdown-toggle').removeClass('btn-primary');
        }
    }

    selectResponseType(value) {
        this.setState({ httpResponseType: value });
    }

    selectMethod(method) {
        this.setState({ httpMethod: method });
    }

    render() {
        function responseBody() {
            if (this.state.httpResponseType === this.HTTP_RESPONSE_TYPES[0]) {
                return React.createElement(
                    DroppableArea,
                    { isOpening: this.state.isOpening },
                    React.createElement('textarea', { placeholder: 'Write your response output or drag and drop a file to it',
                        onFocus: this.showHelpPanel.bind(this, "response"),
                        ref: textarea => {
                            this.elm.responseData = textarea;
                        } })
                );
            } else {
                return React.createElement(
                    'div',
                    null,
                    React.createElement('input', { type: 'text', placeholder: 'Please Enter full file location http or local',
                        'data-http-required': 'true', onFocus: this.showHelpPanel.bind(this, "response"),
                        defaultValue: this.props.fileResponse, className: 'form-control',
                        ref: input => {
                            this.elm.fileResponse = input;
                        } })
                );
            }
        }

        return React.createElement(
            'form',
            { name: "collapse-form-" + this.props.name, onSubmit: this.handleSubmit },
            React.createElement(
                'div',
                { className: 'panel panel-default collapse', role: 'http-mock-panel',
                    'aria-labelledby': this.props.name, id: "collapse-" + this.props.name },
                React.createElement(
                    'div',
                    { className: 'panel-heading http-panel-heading' },
                    React.createElement(
                        'button',
                        { type: 'button', className: 'btn btn-default btn-xs', 'aria-label': 'back or cancel',
                            id: "back-" + this.props.name, 'data-toggle': 'collapse', onClick: this.resetForm,
                            'data-target': "#collapse-" + this.props.name, 'aria-expanded': 'true',
                            'aria-controls': "collapse-" + this.props.name },
                        React.createElement(
                            'span',
                            null,
                            'Back / Cancel'
                        )
                    ),
                    React.createElement(
                        'button',
                        { type: 'submit', className: 'btn btn-default btn-sm add-btn', 'aria-label': 'add',
                            'data-toggle': 'collapse', 'data-target': "#collapse-" + this.props.name, 'aria-expanded': 'true',
                            'aria-controls': "collapse-" + this.props.name },
                        React.createElement(
                            'span',
                            null,
                            this.props.saveBtnText
                        )
                    )
                ),
                React.createElement(
                    'div',
                    { className: 'panel-body panel-collapse' },
                    React.createElement(
                        'div',
                        null,
                        React.createElement(
                            'div',
                            { className: 'input-group' },
                            React.createElement(Dropdown, { className: 'input-group-btn', items: this.HTTP_METHODS,
                                selectedItem: this.state.httpMethod, onSelect: this.selectMethod.bind(this),
                                ref: dropdown => {
                                    this.elm.httpMethod = dropdown;
                                } }),
                            React.createElement('input', { className: 'form-control', type: 'text', 'aria-label': 'request URL or RegExp',
                                onFocus: this.showHelpPanel.bind(this, "url"),
                                onBlur: this.validateForm.bind(this), 'data-http-required': 'true',
                                placeholder: 'Enter URL or RegExp key word', defaultValue: this.props.url,
                                ref: input => {
                                    this.elm.url = input;
                                } })
                        )
                    ),
                    React.createElement(
                        'div',
                        { className: 'nav-container' },
                        React.createElement(
                            'ul',
                            { className: 'nav nav-pills', role: 'tablist' },
                            React.createElement(
                                'li',
                                { role: 'presentation', className: 'active' },
                                React.createElement(
                                    'a',
                                    { 'aria-controls': 'status', role: 'tab', 'data-toggle': 'tab',
                                        onClick: this.hideHelpPanel.bind(this, "headers"),
                                        'data-target': "#status-" + this.props.name },
                                    'Status'
                                )
                            ),
                            React.createElement(
                                'li',
                                { role: 'presentation' },
                                React.createElement(
                                    'a',
                                    { className: 'dropdown', 'aria-controls': 'response', role: 'tab', 'data-toggle': 'tab',
                                        onClick: this.showHelpPanel.bind(this, "response"),
                                        'data-target': "#response-" + this.props.name },
                                    'Response'
                                )
                            ),
                            React.createElement(
                                'li',
                                { role: 'presentation' },
                                React.createElement(
                                    'a',
                                    { 'aria-controls': 'headers', role: 'tab', 'data-toggle': 'tab',
                                        onClick: this.showHelpPanel.bind(this, "headers"),
                                        'data-target': "#headers-" + this.props.name },
                                    'Request Headers'
                                )
                            )
                        ),
                        React.createElement(
                            'div',
                            { className: 'all-tab-contents' },
                            React.createElement(
                                'div',
                                { className: 'tab-content' },
                                React.createElement(
                                    'div',
                                    { role: 'tabpanel', className: "tab-pane fade active in",
                                        id: "status-" + this.props.name },
                                    React.createElement('input', { type: 'number', className: 'form-control', 'aria-label': 'http response status',
                                        placeholder: 'Enter Http Status number', 'data-http-required': 'true',
                                        onFocus: this.showHelpPanel.bind(this, "status"),
                                        onBlur: this.validateForm.bind(this),
                                        ref: input => {
                                            this.elm.status = input;
                                        }
                                    })
                                ),
                                React.createElement(
                                    'div',
                                    { role: 'tabpanel', className: 'tab-pane fade', id: "response-" + this.props.name },
                                    React.createElement(
                                        'div',
                                        { className: 'response-container' },
                                        React.createElement(Dropdown, { className: 'dropdown paddingBottom10px',
                                            items: this.HTTP_RESPONSE_TYPES,
                                            selectedItem: this.state.httpResponseType,
                                            onSelect: this.selectResponseType.bind(this) }),
                                        React.createElement(
                                            'div',
                                            { className: 'data' },
                                            responseBody.bind(this).call()
                                        )
                                    )
                                ),
                                React.createElement(
                                    'div',
                                    { role: 'tabpanel', className: 'tab-pane fade', id: "headers-" + this.props.name },
                                    React.createElement(HeaderInputList, { headerList: this.state.headerList,
                                        onClick: this.showHelpPanel.bind(this, "headers"),
                                        ref: headers => {
                                            this.elm.headers = headers;
                                        } })
                                )
                            )
                        )
                    )
                )
            )
        );
    }
}
class HttpList extends React.Component {

    constructor() {
        super();
        this.state = { httpList: [], listErrorIndicator: [] };
        this.getStoredHttpList(this);
    }

    getErrorIndicator(item) {
        if (JSON.stringify(item).search(/required|invalid/i) !== -1) {
            return "list-group-item-danger";
        }
        return "";
    }

    addNewHttp(httpMock, httpErrorState) {
        var newList = this.state.httpList,
            newErrors = this.state.listErrorIndicator;
        newList.push(httpMock);
        // find any error and update it
        newErrors.push(this.getErrorIndicator(httpErrorState));
        this.setState({ httpList: newList, listErrorIndicator: newErrors }, function () {
            // store http to storage
            birbalJS.requestBackGround(newList.filter(item => !!item), 'httpMock.updateList');
        });
    }

    updateExistingHttp(ind, httpMock, httpErrorState) {
        birbalJS.logger.log(arguments);
        var aList = this.state.httpList,
            newErrors = this.state.listErrorIndicator;
        aList[ind] = httpMock;
        // find any error and update it
        newErrors[ind] = this.getErrorIndicator(httpErrorState);
        this.setState({ httpList: aList, listErrorIndicator: newErrors }, function () {
            // store http to storage
            birbalJS.requestBackGround(aList.filter(item => !!item), 'httpMock.updateList');
        });
    }

    getStoredHttpList(THIS) {
        // get from storage and init state
        new Promise(function (resolve) {
            //birbalJS.informBackground(null, 'httpMock.getMeList');
            birbalJS.requestBackGround(null, 'httpMock.getMeList', { name: 'httpMock.hereIsList', listener: resolve });
        }).then(function (httpList) {
            // on async resolve
            if (httpList) {
                var listErrorIndicator = [];
                httpList.forEach(http => {
                    http.url = birbalJS.toURL(http.url);
                    listErrorIndicator.push('');
                });
                THIS.setState({
                    httpList: THIS.state.httpList.concat(httpList),
                    listErrorIndicator: THIS.state.listErrorIndicator.concat(listErrorIndicator)
                });
            }
        });
    }

    initErrorState(ind, httpErrorState) {
        var newErrors = this.state.listErrorIndicator;
        newErrors[ind] = this.getErrorIndicator(httpErrorState);
        this.setState({ listErrorIndicator: newErrors });
    }

    remove(ind, e) {
        this.state.httpList[ind] = undefined;
        this.state.listErrorIndicator[ind] = undefined;
        this.setState({ httpList: this.state.httpList, listErrorIndicator: this.state.listErrorIndicator }, function () {
            // store http to storage
            //updateHttpList(this.state.httpList.filter((item)=>(!!item)));
            birbalJS.requestBackGround(this.state.httpList.filter(item => !!item), 'httpMock.updateList');
        });
        e.stopPropagation();
        e.preventDefault();
    }

    handleClick(e) {
        showEditHttpPanel(e);
    }

    render() {
        var THIS = this;
        return React.createElement(
            "div",
            { className: "list-group" },
            this.state.httpList.map(function (http, ind) {
                if (http) {
                    return React.createElement(
                        "div",
                        { className: "list-item", "data-list-item-id": 'item-' + ind },
                        React.createElement(
                            "button",
                            { type: "button", id: "url" + ind, "data-toggle": "collapse", "aria-expanded": "true",
                                className: "list-group-item " + THIS.state.listErrorIndicator[ind],
                                "data-target": "#collapse-url" + ind, onClick: THIS.handleClick,
                                "aria-controls": "collapse-url" + ind },
                            React.createElement(
                                "span",
                                { className: "list-group-item-label" },
                                React.createElement(
                                    "span",
                                    { className: "glyphicon glyphicon-trash remove",
                                        onClick: THIS.remove.bind(THIS, ind) },
                                    React.createElement(
                                        "span",
                                        { className: "badge" },
                                        "Trash it "
                                    )
                                ),
                                http.url && http.url.toString(),
                                React.createElement(
                                    "span",
                                    { className: "open-me" },
                                    "Open"
                                )
                            ),
                            React.createElement(
                                "span",
                                { className: "badge" },
                                http.method
                            )
                        ),
                        React.createElement(HttpFormPanel, { name: "url" + ind, responseData: http.response,
                            fileResponse: http.fileResponse, url: http.url, status: http.status,
                            method: http.method, headerList: http.headers,
                            save: THIS.updateExistingHttp.bind(THIS, ind), saveBtnText: "Update",
                            updateInitErrorState: THIS.initErrorState.bind(THIS, ind) })
                    );
                }
            })
        );
    }
}

class HttpNewForm extends React.Component {

    constructor(props) {
        super(props);
        this.state = { resetToggle: true };
    }

    add(httpMock, httpErrorState) {
        this.props.httpList.addNewHttp(httpMock, httpErrorState);
        // dummy state to update the component with default values
        this.setState({ resetToggle: !this.state.resetToggle });
    }

    render() {
        return React.createElement(
            HttpFormPanel,
            { name: "new", saveBtnText: "Add", save: this.add.bind(this), responseData: "", url: "", status: "",
                noValidate: "true", "trigger-reset": this.state.resetToggle },
            " "
        );
    }
}

$(function () {
    // link http list with new to add new to list
    var httpListElm = ReactDOM.render(React.createElement(
        HttpList,
        null,
        " "
    ), document.getElementById('http-list'));

    ReactDOM.render(React.createElement(HttpNewForm, { httpList: httpListElm }), document.getElementById('http-new'));
    $("#new").on("click", showEditHttpPanel);

    $('#close-me').on('click', function () {
        window.close();
    });

    $(".http-input-help .ui-widget-content").draggable({ containment: ".http-input-help", scroll: false }).resizable();

    $(".http-input-help").on("help-panel:hide", function (event, panelName) {
        var panelSelector = panelName ? "." + panelName : "";
        birbalJS.logger.log("panelSelector = " + panelSelector);
        $(".http-input-help .ui-widget-content" + panelSelector).addClass("hide-me");
    }).on("help-panel:show", function (event, panelName) {
        var panelSelector = "." + panelName;
        birbalJS.logger.log("panelSelector = " + panelSelector);
        $(".http-input-help .ui-widget-content" + panelSelector).removeClass("hide-me");
    });
});

function showEditHttpPanel(event) {
    var targetId = "#collapse-" + event.currentTarget.id;
    $(targetId).trigger("openingForm");
    window.setTimeout(function () {
        var target = $(targetId);
        $('html, body').animate({
            scrollTop: target.offset().top - 15
        }, 300);
    }, 100);
}
